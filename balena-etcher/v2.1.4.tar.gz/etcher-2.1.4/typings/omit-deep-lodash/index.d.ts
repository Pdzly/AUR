declare module 'omit-deep-lodash';
