declare module 'path-is-inside';
