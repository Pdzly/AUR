declare module '@balena/sudo-prompt';
